document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('signup-form');
    const ccnum = document.getElementById('ccnum');
    const ccexp = document.getElementById('ccexp');
    const cccvv = document.getElementById('cccvv');

    form.addEventListener('submit', function (event) {
        // Validate credit card number
        if (!/^\d{16}$/.test(ccnum.value)) {
            alert('Please enter a valid 16-digit credit card number.');
            event.preventDefault();
        }

        // Validate CVV
        if (!/^\d{3}$/.test(cccvv.value)) {
            alert('Please enter a valid 3-digit CVV.');
            event.preventDefault();
        }

        // Validate expiry date
        const [month, year] = ccexp.value.split('/');
        if (!/^(0[1-9]|1[0-2])$/.test(month)) {
            alert('Please enter a valid month (01-12) for the expiry date.');
            event.preventDefault();
        }

        if (!/^\d{2}$/.test(year) || parseInt(year) < 23) {
            alert('Please enter a valid year (greater than 23) for the expiry date.');
            event.preventDefault();
        }
    });

    // Additional input restrictions
    ccnum.addEventListener('input', function () {
        this.value = this.value.replace(/\D/g, '').slice(0, 16);
    });

    cccvv.addEventListener('input', function () {
        this.value = this.value.replace(/\D/g, '').slice(0, 3);
    });

    ccexp.addEventListener('input', function () {
        let value = this.value.replace(/[^0-9]/g, '');

        if (value.length > 2) {
            value = value.slice(0, 2) + '/' + value.slice(2, 4);
        }

        this.value = value;
    });

    ccexp.addEventListener('blur', function () {
        const [month, year] = this.value.split('/');
        if (month && !/^(0[1-9]|1[0-2])$/.test(month)) {
            alert('Please enter a valid month (01-12) for the expiry date.');
            this.focus();
        } else if (year && (!/^\d{2}$/.test(year) || parseInt(year) < 23)) {
            alert('Please enter a valid year (greater than 23) for the expiry date.');
            this.focus();
        }
    });
});
