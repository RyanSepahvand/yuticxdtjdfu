document.addEventListener('DOMContentLoaded', function () {
    const chatWindow = document.getElementById('chat-window');
    const chatMessages = document.getElementById('chat-messages');
    const chatInput = document.getElementById('chat-input');
    const sendButton = document.getElementById('send-button');
    const settingsButton = document.getElementById('settings-button');
    const settingsModal = document.getElementById('settings-modal');
    const saveSettings = document.getElementById('save-settings');
    const closeSettings = document.getElementById('close-settings');
    const chatTitleInput = document.getElementById('chat-title-input');
    const chatTitle = document.querySelector('.chat-title');
    const groupChats = document.querySelectorAll('.group-chat');
    const owner = true; // Assume owner for this example, you can dynamically set this based on user

    // Function to send a message
    function sendMessage() {
        const messageText = chatInput.value;
        if (messageText.trim()) {
            const message = document.createElement('div');
            message.classList.add('message', 'owner');
            message.innerHTML = `
                <img src="owner.jpg" alt="Owner">
                <div class="text">${messageText}</div>
            `;
            chatMessages.appendChild(message);
            chatMessages.scrollTop = chatMessages.scrollHeight;
            chatInput.value = '';
            // Simulate sending message to server
            simulateMessageSending(messageText);
        }
    }

    // Simulate sending message to server (example function)
    function simulateMessageSending(messageText) {
        // Replace with actual server communication logic
        setTimeout(() => {
            const responseMessage = document.createElement('div');
            responseMessage.classList.add('message');
            responseMessage.innerHTML = `
                <img src="user1.jpg" alt="User 1">
                <div class="text">${messageText} received!</div>
            `;
            chatMessages.appendChild(responseMessage);
            chatMessages.scrollTop = chatMessages.scrollHeight;
        }, 1000);
    }

    // Function to load chat messages (simulate for demo)
    function loadChatMessages(chatId) {
        // Simulate loading chat messages from server
        // Replace with actual server communication logic
        setTimeout(() => {
            const messages = [
                { sender: 'user1.jpg', text: 'Hello!' },
                { sender: 'owner.jpg', text: 'Hi!' },
                { sender: 'user1.jpg', text: 'How are you?' },
                { sender: 'owner.jpg', text: 'I\'m good, thanks!' },
                { sender: 'user1.jpg', text: 'What about you?' },
            ];

            messages.forEach(msg => {
                const message = document.createElement('div');
                message.classList.add('message');
                message.innerHTML = `
                    <img src="${msg.sender}" alt="User">
                    <div class="text">${msg.text}</div>
                `;
                chatMessages.appendChild(message);
            });

            chatMessages.scrollTop = chatMessages.scrollHeight;
        }, 500);
    }

    // Event listeners

    // Handle clicking on a group chat to load messages
    groupChats.forEach(chat => {
        chat.addEventListener('click', function () {
            const chatId = this.getAttribute('data-chat-id');
            chatTitle.textContent = `Chat with ${this.querySelector('.user-name').textContent}`;
            chatMessages.innerHTML = ''; // Clear previous messages
            loadChatMessages(chatId);
        });
    });

    // Send message button click event
    sendButton.addEventListener('click', sendMessage);

    // Enter key press event in chat input to send message
    chatInput.addEventListener('keypress', function (e) {
        if (e.key === 'Enter') {
            sendMessage();
        }
    });

    // Settings button click event
    settingsButton.addEventListener('click', function () {
        if (owner) {
            settingsModal.style.display = 'flex';
        }
    });

    // Save settings button click event
    saveSettings.addEventListener('click', function () {
        chatTitle.textContent = chatTitleInput.value;
        settingsModal.style.display = 'none';
    });

    // Close settings button click event
    closeSettings.addEventListener('click', function () {
        settingsModal.style.display = 'none';
    });
});
document.addEventListener('DOMContentLoaded', function () {
    // ... Existing code from previous response

    const emojiButton = document.createElement('button');
    emojiButton.innerHTML = '&#x1F642;'; // Emoji icon (smiling face)
    emojiButton.classList.add('emoji-button');
    chatInput.parentNode.insertBefore(emojiButton, chatInput.nextSibling);

    const emojiPicker = document.createElement('div');
    emojiPicker.classList.add('emoji-picker');
    emojiPicker.innerHTML = `
        <span>&#x1F642;</span>
        <span>&#x1F600;</span>
        <span>&#x1F601;</span>
        <!-- Add more emojis as needed -->
    `;
    document.body.appendChild(emojiPicker);

    emojiButton.addEventListener('click', function () {
        emojiPicker.classList.toggle('active');
    });

    emojiPicker.addEventListener('click', function (e) {
        if (e.target.tagName === 'SPAN') {
            chatInput.value += e.target.innerHTML;
        }
    });

    const fileButton = document.createElement('button');
    fileButton.innerHTML = 'Attach File';
    fileButton.classList.add('file-label');
    chatInput.parentNode.insertBefore(fileButton, chatInput.nextSibling);

    const fileUpload = document.createElement('div');
    fileUpload.classList.add('file-upload');
    fileUpload.innerHTML = `
        <input type="file" class="file-input">
    `;
    document.body.appendChild(fileUpload);

    fileButton.addEventListener('click', function () {
        const fileInput = fileUpload.querySelector('.file-input');
        fileInput.click();
    });

    fileUpload.querySelector('.file-input').addEventListener('change', function () {
        const file = this.files[0];
        if (file) {
            sendMessage(`Attached file: ${file.name}`);
        }
    });

    // Prevent default form submit behavior
    const signupForm = document.querySelector('.signup-form');
    signupForm.addEventListener('submit', function (event) {
        event.preventDefault();
        // Additional validation or form handling logic can be added here
    });
});


