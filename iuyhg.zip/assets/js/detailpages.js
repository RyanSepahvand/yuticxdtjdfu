function sendMessage() {
    const chatInput = document.getElementById('chat-input');
    const chatBox = document.getElementById('chat-box');

    if (chatInput.value.trim() !== "") {
        const newMessage = document.createElement('p');
        newMessage.textContent = chatInput.value;
        chatBox.appendChild(newMessage);

        chatInput.value = "";
        chatBox.scrollTop = chatBox.scrollHeight;
    }
}
function sendMessage() {
    const chatInput = document.getElementById('chat-input');
    const chatBox = document.getElementById('chat-box');

    if (chatInput.value.trim() !== "") {
        const newMessage = document.createElement('div');
        newMessage.classList.add('chat-message');
        newMessage.innerHTML = `
            <img src="https://via.placeholder.com/40" alt="Profile Picture">
            <div class="chat-message-content">
                <p>${chatInput.value}</p>
            </div>
        `;
        chatBox.appendChild(newMessage);

        chatInput.value = "";
        chatBox.scrollTop = chatBox.scrollHeight;
    }
}

// Enable sending message by pressing Enter
document.getElementById('chat-input').addEventListener('keydown', function(event) {
    if (event.key === 'Enter') {
        event.preventDefault();
        sendMessage();
    }
});
function sendMessage() {
    const chatInput = document.getElementById('chat-input');
    const chatBox = document.getElementById('chat-box');

    if (chatInput.value.trim() !== "") {
        const newMessage = document.createElement('div');
        newMessage.classList.add('chat-message');
        newMessage.innerHTML = `
            <img src="https://via.placeholder.com/40" alt="Profile Picture">
            <div class="chat-message-content">
                <p>${chatInput.value}</p>
            </div>
        `;
        chatBox.appendChild(newMessage);

        chatInput.value = "";
        chatBox.scrollTop = chatBox.scrollHeight;
    }
}

// Enable sending message by pressing Enter
document.getElementById('chat-input').addEventListener('keydown', function(event) {
    if (event.key === 'Enter') {
        event.preventDefault();
        sendMessage();
    }
});
